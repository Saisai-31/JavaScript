function airecarre(){
    let largeur = parseInt(prompt("Entrez la taille d'un côté en cm"));

    let result = largeur * largeur;
    alert("L'aire du carré est : "+result+"cm²")
}