function airerectangle(){
    let largeur = parseInt(prompt("Entrez la largeur du rectangle en cm"));
    let hauteur = parseInt(prompt("Entrez la hauteur du rectangle en cm"));

    let result = largeur * hauteur;
    alert("L'aire du rectangle est : "+result+"cm²")
}